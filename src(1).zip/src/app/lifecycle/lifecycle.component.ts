import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lifecycle',
  templateUrl: './lifecycle.component.html',
  styleUrls: ['./lifecycle.component.css']
})
export class LifecycleComponent  {
  
  
  data:number=100;

  constructor() {
    console.log(`new - data is ${this.data}`);
   }
   ngOnchanges(){
     console.log(`ngOnChanges - data is ${this.data}`);
   }

  ngOnInit() {
    console.log(`ngOnInit - data is ${this.data}`);
  }
  ngDoCheck(){
    console.log("ngDoCheck");
  }
  ngAfterContentInit(){
    console.log("ngAfterContentInit");
  }
  ngAfterContentChecked(){
    console.log(" ngAfterContentChecked");
  }
  ngAfterViewInit(){
    console.log("ngAfterViewInit");
  }
  ngAfterViewChecked(){
    console.log("ngAfterViewChecked");
  }
  ngOnDestroy(){
    console.log(" ngOnDestroy");
  }

  incrementNumberBy100():void{
    this.data+=100;
  }
  decrementNumberBy10():void{
    this.data -=10;
  }



}
