import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { customerService } from '../services/customer.service';

@Component({
  selector: 'app- add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddcustomerComponent implements OnInit {

  addForm: FormGroup;
  submitted: boolean =false;
  

  constructor(private formBuilder:FormBuilder, private router: Router,
              private customerService:customerService) { }

  

   //onsubmit() function
   onSubmit(){
     this.submitted =true;
     if(this.addForm.invalid){
       return;
     }
     console.log(this.addForm.value);

     this.customerService.createcustomer(this.addForm.value)
     .subscribe(date=>{
       alert(this.addForm.controls.firstName.value+'record is added successfully ..!');
       this.router.navigate(['list-customer']);
     })
   }
   ngOnInit() {
    this.addForm=this.formBuilder.group({
     id:[],
     firstName:['',Validators.required],
     lastName:['',Validators.required],
      email:['',[Validators.required,Validators.email]],
      password:['',Validators.required],
      age:['',[Validators.required, Validators.min(18),Validators.max(55)]],
      mobileNumber:['',[Validators.required,Validators.pattern("[6-9][0-9]{9}")]]
      
    })
   }
  }