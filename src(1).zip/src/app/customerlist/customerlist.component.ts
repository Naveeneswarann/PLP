import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customerlist',
  templateUrl: './customerlist.component.html',
  styleUrls: ['./customerlist.component.css']
})
export class customerlistComponent implements OnInit {
  /// Instance Variable 
  // bydefault public in typescript
  customerlistForm: FormGroup;
  submitted: boolean =false;
  invalidcustomerlist: boolean =false;

  constructor(private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.customerlistForm=this.formBuilder.group({
     email:['',Validators.required],
     password:['',Validators.required]
    })
   }
   
  onSubmit(){
    this.submitted=true;
    //if validation failed, it should return
    //to validate again
    if(this.customerlistForm.invalid){
     return;
    }
    let customername
    =this.customerlistForm.controls.email.value;
    let password
    =this.customerlistForm.controls.password.value;

    if ( customername   
        =="customerlist@gmail.com" && password=="123456789")
        {
          localStorage.setItem("customername",customername);
          // localStorage.setItem("password",password);
          this.router.navigate(['list-customer']);
        }
    if(this.customerlistForm.controls.email.value
    =="customerlist@gmail.com"&&
   this.customerlistForm.controls.password.value=="123456789")
   {
    localStorage.setItem("customername",customername);
    this.router.navigate(['list-customer']);
   }

   else{
    this.invalidcustomerlist=true;
   }
   }
  
}
