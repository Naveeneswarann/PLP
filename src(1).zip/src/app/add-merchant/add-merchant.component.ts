import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { merchantService } from '../services/merchant.service';

@Component({
  selector: 'app-add-merchant',
  templateUrl: './add-merchant.component.html',
  styleUrls: ['./add-merchant.component.css']
})
export class AddmerchantComponent implements OnInit {

  addForm: FormGroup;
  submitted: boolean =false;
  

  constructor(private formBuilder:FormBuilder, private router: Router,
              private merchantService:merchantService) { }

  

   //onsubmit() function
   onSubmit(){
     this.submitted =true;
     if(this.addForm.invalid){
       return;
     }
     console.log(this.addForm.value);

     this.merchantService.createmerchant(this.addForm.value)
     .subscribe(date=>{
       alert(this.addForm.controls.firstName.value+'record is added successfully ..!');
       this.router.navigate(['list-merchant']);
     })
   }
   ngOnInit() {
    this.addForm=this.formBuilder.group({
     id:[],
     firstName:['',Validators.required],
     lastName:['',Validators.required],
      email:['',[Validators.required,Validators.email]],
      password:['',Validators.required],
      age:['',[Validators.required, Validators.min(18),Validators.max(55)]],
      mobileNumber:['',[Validators.required,Validators.pattern("[6-9][0-9]{9}")]]
      
    })
   }
  }