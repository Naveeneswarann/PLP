export class customer {
   id: number;
    firstName: string;
    lastName: string;
    email: string;
    password: string
    age: number;
     mobileNumber: string;
    
    
}
