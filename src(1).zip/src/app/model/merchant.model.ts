export class merchant{

    id: number;
    firstName: string;
    lastName: string;
    email: string;
    password:string;
    age:number;
    mobileNumber:number;
  
}