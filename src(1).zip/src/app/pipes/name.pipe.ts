import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'name'
})
export class NamePipe implements PipeTransform {

  transform(customerList:any, searchText:any) {
    if(searchText)
    return customerList.filter(x=>
      x.firstName.toLowerCase()
      .startswith(searchText.toLowerCase()));
      return customerList;
  }

}
