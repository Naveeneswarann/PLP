import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { customerlistComponent } from './customerlist/customerlist.component';
import { AddcustomerComponent } from './add-customer/add-customer.component';
import { ListcustomerComponent } from './list-customer/list-customer.component';
import { EditcustomerComponent } from './edit-customer/edit-customer.component';

import { merchantlistComponent } from './merchantlist/merchantlist.component';
import { AddmerchantComponent } from './add-merchant/add-merchant.component';
import { ListmerchantComponent } from './list-merchant/list-merchant.component';
import { EditmerchantComponent } from './edit-merchant/edit-merchant.component';

const routes: Routes = [
                        {path:'home',component:HomeComponent},
                        {path:'customerlist',component:customerlistComponent},
                        {path:'add-customer',component:AddcustomerComponent},
                        {path:'list-customer',component:ListcustomerComponent},
                        {path:'edit-customer/:id',component:EditcustomerComponent},
                        
                        {path:'merchantlist',component:merchantlistComponent},
                        {path:'add-merchant',component:AddmerchantComponent},
                        {path:'list-merchant',component:ListmerchantComponent},
                        {path:'edit-merchant/:id',component:EditmerchantComponent},
                      
                        {path:'',component:HomeComponent},
                      
                        //or
                        //{path:'',redirectTo:'/home',pathMatch:'full'},
                        {path:'**',component:HomeComponent},];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
