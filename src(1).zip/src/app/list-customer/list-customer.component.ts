import { Component, OnInit } from '@angular/core';
import { customer } from '../model/customer.model';
import { Router } from '@angular/router';
import { customerService } from '../services/customer.service';


@Component({
  selector: 'app-list-customer',
  templateUrl: './list-customer.component.html',
  styleUrls: ['./list-customer.component.css']
})
export class ListcustomerComponent implements OnInit {

  //create an array of customer class
  customers:customer[];
  public searchText:any;

  //constructor dependency injection
  constructor(private router:Router,
  private customerService:customerService) { }

  //loading all customers as soon as component
  //gets loaded
  

  ngOnInit() {
    if(localStorage.getItem("customername")!=null){
      this.customerService.getcustomers().subscribe(data=>{
        this.customers=data;
      });
    }
    else{
      this.router.navigate(['/customerlist']);
    }
  }
  //logoff customer
  logOutcustomer():void{
    if(localStorage.getItem("customername")){
      localStorage.removeItem("customername");
      this.router.navigate(['/customerlist']);
    }
  }
  //delete customer
  
    deletecustomer(customers:customer):void{
    let result=confirm("Do you want to delete customer?")
    if(result){
      this.customerService.deletecustomer(customers.id)
      .subscribe(() => {
          this.customers = this.customers.filter(u => u !== customers);
        })
    }
    }
     //modify customer
  editcustomer(customers:customer):void{
    localStorage.removeItem("editcustomerId");
    localStorage.setItem("editcustomerId",
    customers.id.toString());
    //this.router.navigate(['edit-customer']);
    this.router.navigate(['edit-customer', customers.id.toString()]);
  }
  //add new customer
  addcustomer():void{
    this.router.navigate(['add-customer']);
  }
}
 


