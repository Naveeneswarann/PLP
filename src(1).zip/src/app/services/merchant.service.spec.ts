import { TestBed } from '@angular/core/testing';

import { merchantService } from './merchant.service';

describe('merchantService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: merchantService = TestBed.get(merchantService);
    expect(service).toBeTruthy();
  });
});
