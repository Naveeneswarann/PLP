import { Injectable } from '@angular/core';

import { merchant } from '../model/merchant.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class merchantService {

  constructor(private http:HttpClient) { }
  baseUrl:string="http://localhost:3000/merchant"

  //get all merchant
  getmerchants(){
    return this.http.get<merchant[]>(this.baseUrl);
  }

  //get merchant by id
  getmerchantById(id:number){
    return this.http.get<merchant[]>(this.baseUrl+'/'+id);
  }

  //create merchant
  createmerchant(merchant:merchant){
    return this.http.post(this.baseUrl,merchant);
  }

  //modify merchant
  updatemerchant(merchant:merchant){
    return this.http.put(this.baseUrl+'/'+merchant.id,merchant);
  }

  //delete merchant
  deletemerchant(id:number){
    return this.http.delete(this.baseUrl+'/'+id);
  }
}


