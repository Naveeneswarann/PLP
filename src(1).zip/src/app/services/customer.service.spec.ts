import { TestBed } from '@angular/core/testing';

import { customerService } from './customer.service';

describe('customerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: customerService = TestBed.get(customerService);
    expect(service).toBeTruthy();
  });
});
