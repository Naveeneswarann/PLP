import { Injectable } from '@angular/core';

import { customer } from '../model/customer.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class customerService {

  constructor(private http:HttpClient) { }
  baseUrl:string="http://localhost:3000/customer"

  //get all customer
  getcustomers(){
    return this.http.get<customer[]>(this.baseUrl);
  }

  //get customer by id
  getcustomerById(id:number){
    return this.http.get<customer[]>(this.baseUrl+'/'+id);
  }

  //create customer
  createcustomer(customer:customer){
    return this.http.post(this.baseUrl,customer);
  }

  //modify customer
  updatecustomer(customer:customer){
    return this.http.put(this.baseUrl+'/'+customer.id,customer);
  }

  //delete customer
  deletecustomer(id:number){
    return this.http.delete(this.baseUrl+'/'+id);
  }
}


