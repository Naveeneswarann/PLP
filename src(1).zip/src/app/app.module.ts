import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';

import { customerlistComponent } from './customerlist/customerlist.component';
import { AddcustomerComponent } from './add-customer/add-customer.component';
import { EditcustomerComponent } from './edit-customer/edit-customer.component';
import { ListcustomerComponent } from './list-customer/list-customer.component';

import { merchantlistComponent } from './merchantlist/merchantlist.component';
import { AddmerchantComponent } from './add-merchant/add-merchant.component';
import { EditmerchantComponent } from './edit-merchant/edit-merchant.component';
import { ListmerchantComponent } from './list-merchant/list-merchant.component';


import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { SqrtPipe } from './pipes/sqrt.pipe';
import { NamePipe } from './pipes/name.pipe';
import { LifecycleComponent } from './lifecycle/lifecycle.component';


@NgModule({
  // all customer defined components,derivatives,pipes
  declarations: [
    AppComponent,
    HomeComponent,
    
    customerlistComponent,
    AddcustomerComponent,
    EditcustomerComponent,
    ListcustomerComponent,
    
    merchantlistComponent,
    AddmerchantComponent,
    EditmerchantComponent,
    ListmerchantComponent,
    
    SqrtPipe,
    NamePipe,
    LifecycleComponent,
  ],

  //all customer defined and predefinide
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule
  ],
  //all customer defined service
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
