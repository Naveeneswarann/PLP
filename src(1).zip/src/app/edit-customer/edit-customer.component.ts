import { Component, OnInit } from '@angular/core';
import { customer } from '../model/customer.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { customerService } from '../services/customer.service';


@Component({
  selector: 'app-edit-customer',
  templateUrl: './edit-customer.component.html',
  styleUrls: ['./edit-customer.component.css']
})
export class EditcustomerComponent implements OnInit {
  editForm: FormGroup;
  submitted: boolean =false;
  customer: customer;
  customerId: string;
  

  constructor(private formBuilder:FormBuilder, private router: Router,
              private route:ActivatedRoute,
              private customerService:customerService) {
                this.route.params.subscribe(params => this.customerId = params['id']);
                console.log(this.customerId);
               }
              
  //logOff customer
  logOutcustomer(){
    if(localStorage.getItem("customername")!=null){
      localStorage.removeItem("customername");
      this.router.navigate(['/customerlist'])
    }
  }


  ngOnInit() {
    //if(localStorage.getItem("customername")!=null){
      //let customerId=localStorage.getItem("editcustomerId");
      
    if(this.customerId != null){
      if(!this.customerId){
        alert('Invalid Action');
        this.router.navigate(['list-customer']);
        return;
      }
      this.editForm=this.formBuilder.group({
        id:[],
        firstName:['',Validators.required],
        lastName:['',Validators.required],
        email:['',[Validators.required,Validators.email]],
        password:['',Validators.required],
        age:['',[Validators.required, Validators.min(18),Validators.max(55)]],
        mobileNumber:['',[Validators.required,Validators.pattern("[6-9][0-9]{9}")]]
      });
      this.customerService.getcustomerById(+this.customerId).subscribe(data=>{
        this.editForm.setValue(data)
      });
    }
    else{
      this.router.navigate(['/customerlist']);
    }
  }

  onSubmit(){
    this.submitted =true;
    if(this.editForm.invalid){
      return;
    }
    console.log(this.editForm.value);

    this.customerService.updatecustomer(this.editForm.value)
    .subscribe(date=>{
      alert(this.editForm.controls.firstName.value+'record is edited successfully ..!');
      this.router.navigate(['list-customer']);
    })
  }

}
