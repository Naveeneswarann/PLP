import { Component, OnInit } from '@angular/core';
import { merchant } from '../model/merchant.model';
import { Router } from '@angular/router';
import { merchantService } from '../services/merchant.service';


@Component({
  selector: 'app-list-merchant',
  templateUrl: './list-merchant.component.html',
  styleUrls: ['./list-merchant.component.css']
})
export class ListmerchantComponent implements OnInit {

  //create an array of merchant class
  merchants:merchant[];
  public searchText:any;

  //constructor dependency injection
  constructor(private router:Router,
  private merchantService:merchantService) { }

  //loading all merchants as soon as component
  //gets loaded
  

  ngOnInit() {
    if(localStorage.getItem("merchantname")!=null){
      this.merchantService.getmerchants().subscribe(data=>{
        this.merchants=data;
      });
    }
    else{
      this.router.navigate(['/merchantlist']);
    }
  }
  //logoff merchant
  logOutmerchant():void{
    if(localStorage.getItem("merchantname")){
      localStorage.removeItem("merchantname");
      this.router.navigate(['/merchantlist']);
    }
  }
  //delete merchant
  
    deletemerchant(merchants:merchant):void{
    let result=confirm("Do you want to delete merchant?")
    if(result){
      this.merchantService.deletemerchant(merchants.id)
      .subscribe(data=>{
        this.merchants=this.merchants.filter
        (u=> u!==merchants);
      })
    }
    }
     //modify merchant
  editmerchant(merchants:merchant):void{
    localStorage.removeItem("editmerchantId");
    localStorage.setItem("editmerchantId",
    merchants.id.toString());
    //this.router.navigate(['edit-merchant']);
    this.router.navigate(['edit-merchant', merchants.id.toString()]);
  }
  //add new merchant
  addmerchant():void{
    this.router.navigate(['add-merchant']);
  }
}
 


