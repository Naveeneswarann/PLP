import { Component, OnInit } from '@angular/core';
import { merchant } from '../model/merchant.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { merchantService } from '../services/merchant.service';


@Component({
  selector: 'app-edit-merchant',
  templateUrl: './edit-merchant.component.html',
  styleUrls: ['./edit-merchant.component.css']
})
export class EditmerchantComponent implements OnInit {
  editForm: FormGroup;
  submitted: boolean =false;
  merchant: merchant;
  merchantId: string;
  

  constructor(private formBuilder:FormBuilder, private router: Router,
              private route:ActivatedRoute,
              private merchantService:merchantService) {
                this.route.params.subscribe(params => this.merchantId = params['id']);
                console.log(this.merchantId);
               }
              
  //logOff merchant
  logOutmerchant(){
    if(localStorage.getItem("merchantname")!=null){
      localStorage.removeItem("merchantname");
      this.router.navigate(['/merchantlist'])
    }
  }


  ngOnInit() {
    //if(localStorage.getItem("merchantname")!=null){
      //let merchantId=localStorage.getItem("editmerchantId");
      
    if(this.merchantId != null){
      if(!this.merchantId){
        alert('Invalid Action');
        this.router.navigate(['list-merchant']);
        return;
      }
      this.editForm=this.formBuilder.group({
        id:[],
        firstName:['',Validators.required],
        lastName:['',Validators.required],
        email:['',[Validators.required,Validators.email]],
        password:['',Validators.required],
        age:['',[Validators.required, Validators.min(18),Validators.max(55)]],
        mobileNumber:['',[Validators.required,Validators.pattern("[6-9][0-9]{9}")]]
      });
      this.merchantService.getmerchantById(+this.merchantId).subscribe(data=>{
        this.editForm.setValue(data)
      });
    }
    else{
      this.router.navigate(['/merchantlist']);
    }
  }

  onSubmit(){
    this.submitted =true;
    if(this.editForm.invalid){
      return;
    }
    console.log(this.editForm.value);

    this.merchantService.updatemerchant(this.editForm.value)
    .subscribe(date=>{
      alert(this.editForm.controls.firstName.value+'record is edited successfully ..!');
      this.router.navigate(['list-merchant']);
    })
  }

}
