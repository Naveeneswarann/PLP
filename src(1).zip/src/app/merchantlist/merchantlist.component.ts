import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-merchantlist',
  templateUrl: './merchantlist.component.html',
  styleUrls: ['./merchantlist.component.css']
})
export class merchantlistComponent implements OnInit {
  /// Instance Variable 
  // bydefault public in typescript
  merchantlistForm: FormGroup;
  submitted: boolean =false;
  invalidmerchantlist: boolean =false;

  constructor(private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.merchantlistForm=this.formBuilder.group({
     email:['',Validators.required],
     password:['',Validators.required]
    })
   }
   
  onSubmit(){
    this.submitted=true;
    //if validation failed, it should return
    //to validate again
    if(this.merchantlistForm.invalid){
     return;
    }
    let merchantname
    =this.merchantlistForm.controls.email.value;
    let password
    =this.merchantlistForm.controls.password.value;

    if ( merchantname   
        =="merchantlist@gmail.com" && password=="123456789")
        {
          localStorage.setItem("merchantname",merchantname);
          // localStorage.setItem("password",password);
          this.router.navigate(['list-merchant']);
        }
    if(this.merchantlistForm.controls.email.value
    =="merchantlist@gmail.com"&&
   this.merchantlistForm.controls.password.value=="123456789")
   {
    localStorage.setItem("merchantname",merchantname);
    this.router.navigate(['list-merchant']);
   }

   else{
    this.invalidmerchantlist=true;
   }
   }
  
}
